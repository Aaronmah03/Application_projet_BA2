package com.example.plotter_controleur

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View

import androidx.annotation.RequiresApi
import com.example.plotter_controleur.view_gestion.Vecteur2
import java.lang.Math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.*

class drawthread( var surfaceView: DrawView,private val activity: MainActivity) {
    var pts=arrayListOf<Vecteur2>()
    var drawPoints= arrayListOf<Vecteur2>()
    var actualFingerPos=Vecteur2(0f,0f)
    var ptsIndice=0
    var radius=Vecteur2(activity.height.toFloat(),activity.width.toFloat()).length()/500
    var particularPoint= arrayListOf<point>()

    @SuppressLint("ClickableViewAccessibility")
    fun init() {
        surfaceView.setOnTouchListener(View.OnTouchListener { _, event ->
            handleTouch(event)
            return@OnTouchListener false
        })}

    fun clear(){
        surfaceView.clearDrawables()
        pts.clear()
        ptsIndice=0
        drawPoints.clear()
        particularPoint.clear()
        actualFingerPos=Vecteur2(0f,0f)
    }

    fun handleTouch(event: MotionEvent){when(event.action){
        MotionEvent.ACTION_DOWN ->getFirst(event)
        MotionEvent.ACTION_MOVE -> getPos(event)
        MotionEvent.ACTION_UP -> stopDrawing(event)

    }}
    fun getFirst(e:MotionEvent){
        if(!activity.onC){drawPoints.add(Vecteur2(e.x,e.y))}

        pts.add(Vecteur2(e.x,e.y))

        ptsIndice=pts.size-1

    }
    fun getPos(e:MotionEvent){

        actualFingerPos= Vecteur2(e.x,e.y)
        if (activity.onT){
            Continuous(e)
        }
    }



    fun stopDrawing(e:MotionEvent){
        ptsIndice=pts.size-1
        actualFingerPos=Vecteur2(e.x,e.y)


        if(activity.onC){drawcircle()}
        if(activity.onR){drawrect()}
        if(activity.onL){ pts.add(Vecteur2(e.x,e.y));drawline()}
        if (!activity.onC){drawPoints.add(actualFingerPos)}
    ptsIndice=pts.size-1}


    fun drawrect(){
        val dx=actualFingerPos.x-pts[ptsIndice].x
        val dy=actualFingerPos.y-pts[ptsIndice].y
        if(dx>0){
            for (i in pts[ptsIndice].x.toInt() .. actualFingerPos.x.toInt()){
                val x= i
                val y =pts[ptsIndice].y
                val yp=actualFingerPos.y
                surfaceView.addDrawable(point(Vecteur2(x.toFloat(),y),radius))
                surfaceView.addDrawable(point(Vecteur2(x.toFloat(),yp),radius))
                if (i == (0.25*dy).toInt() ||i == (0.5*dy).toInt() || i == (0.75*dy).toInt() ||i == dy.toInt()){drawPoints.add(Vecteur2(x.toFloat(),y))}

                if (i == (0.25*dy).toInt() ||i == (0.5*dy).toInt() || i == (0.75*dy).toInt() ||i == dy.toInt()){drawPoints.add(Vecteur2(x.toFloat(),yp))}
                }
            }
        if (dx<0){
            for (i in actualFingerPos.x.toInt()..pts[ptsIndice].x.toInt() ){
                val x= i
                val y =pts[ptsIndice].y
                val yp=actualFingerPos.y
                surfaceView.addDrawable(point(Vecteur2(x.toFloat(),y),radius))
                surfaceView.addDrawable(point(Vecteur2(x.toFloat(),yp),radius))
                if (i == (0.25*dy).toInt() ||i == (0.5*dy).toInt() || i == (0.75*dy).toInt() ||i == dy.toInt()){drawPoints.add(Vecteur2(x.toFloat(),y))}

                if (i == (0.25*dy).toInt() ||i == (0.5*dy).toInt() || i == (0.75*dy).toInt() ||i == dy.toInt()){drawPoints.add(Vecteur2(x.toFloat(),yp))}
            }}
        if(dy<0){
            for (i in actualFingerPos.y.toInt() .. pts[ptsIndice].y.toInt()){
                val x=pts[ptsIndice].x
                val y =i
                val xp=actualFingerPos.x
                if (i == (0.25*dy).toInt() ||i == (0.5*dy).toInt() || i == (0.75*dy).toInt() ||i == dy.toInt()){drawPoints.add(Vecteur2(x,y.toFloat()))}

                if (i == (0.25*dy).toInt() ||i == (0.5*dy).toInt() || i == (0.75*dy).toInt() ||i == dy.toInt()){drawPoints.add(Vecteur2(xp,y.toFloat()))}
                surfaceView.addDrawable(point(Vecteur2(x,y.toFloat()),radius))

                surfaceView.addDrawable(point(Vecteur2(xp,y.toFloat()),radius))

            }
        }
        if(dy>0){
            for (i in pts[ptsIndice].y.toInt() ..actualFingerPos.y.toInt() ){
                val x=pts[ptsIndice].x
                val y =i
                val xp=actualFingerPos.x

                if (i == (0.25*dy).toInt() ||i == (0.5*dy).toInt() || i == (0.75*dy).toInt() ||i == dy.toInt()){drawPoints.add(Vecteur2(x,y.toFloat()))}

                if (i == (0.25*dy).toInt() ||i == (0.5*dy).toInt() || i == (0.75*dy).toInt() ||i == dy.toInt()){drawPoints.add(Vecteur2(xp,y.toFloat()))}
                surfaceView.addDrawable(point(Vecteur2(x,y.toFloat()),radius))
               surfaceView.addDrawable(point(Vecteur2(xp,y.toFloat()),radius))

            }
        }
        surfaceView.draw()
    }
    fun Continuous(e: MotionEvent){

        pts.add(Vecteur2(e.x,e.y))
        ptsIndice=pts.size-1
        drawPoints.add(pts[ptsIndice])
        surfaceView.addDrawable(point(pts[ptsIndice],radius))
        val dx=actualFingerPos.x-pts[ptsIndice-1].x
        val dy=actualFingerPos.y-pts[ptsIndice-1].y
        val alpha= Vecteur2(dx,dy).arctan()
        val n =(Vecteur2(dx,dy).length())/radius
        var a=0f
        val arrayList= arrayListOf<Float>()
        for(k in 0..n.toInt()){
            arrayList.add(2*radius*k)
        }
        for (k in arrayList ){
            if (dx<0){a=-k}
            else{a=k}
           surfaceView.addDrawable(point(pts[ptsIndice-1]+Vecteur2(a*(cos(alpha))/2,a*(sin(alpha))/2),radius))
        }
        surfaceView.draw()
    }


    fun drawcircle(){
        val rad= Vecteur2(pts[ptsIndice].x-actualFingerPos.x,pts[ptsIndice].y-actualFingerPos.y).length()
        println("rad")
        val ar= arrayListOf<Int>()
        val theta= arrayListOf<Float>()
        for (i in 1..16){theta.add((2*PI/i).toFloat())}
        for (i in 0..1400){ar.add(i)}
        for (i in ar){
            println("in for")
            val x= rad*cos((i* PI /700))
            val y =rad*sin((i* PI /700))
            println("before add")

            surfaceView.addDrawable(point(pts[ptsIndice]+Vecteur2(x.toFloat(),y.toFloat()),radius))
            for (k in theta ){if((cos((i* PI /700))).toFloat()==k){drawPoints.add(pts[ptsIndice]+Vecteur2(x.toFloat(),y.toFloat()))}}


        }
        surfaceView.draw()

    }
    fun drawline(){

        ptsIndice=pts.size-1

        surfaceView.addDrawable(point(pts[ptsIndice],radius))
        val dx=actualFingerPos.x-pts[ptsIndice-1].x
        val dy=actualFingerPos.y-pts[ptsIndice-1].y
        val alpha= Vecteur2(dx,dy).arctan()
        val n =(Vecteur2(dx,dy).length())/radius
        val arrayList= arrayListOf<Float>()
        for(k in 0..n.toInt()){
            arrayList.add(2*radius*k)
        }
        var a=0f
        for (k in arrayList ){
            if (dx<0){a=-k}
            else{a=k}
            surfaceView.addDrawable(point(pts[ptsIndice-1]+Vecteur2(a*(cos(alpha))/2,a*(sin(alpha))/2),radius))
        }
    surfaceView.draw()}





}