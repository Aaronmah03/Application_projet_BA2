package com.example.plotter_controleur

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import androidx.annotation.RequiresApi
import com.example.plotter_controleur.view_gestion.Vecteur2

class rectangle (var LeftCorner: Vecteur2, var RightCorner:Vecteur2,var radius:Float):drawingGestion(){
    val paint = Paint()

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun draw (canvas: Canvas?) {
        paint.color = Color.WHITE
        var dx=RightCorner.x-LeftCorner.x
        var dy=RightCorner.y-LeftCorner.y

        println("before")
        if(dx>0){
            for (i in LeftCorner.x.toInt() .. RightCorner.x.toInt()){
                println("in for")

                var x= i
                var y =LeftCorner.y
                var yp=RightCorner.y
                canvas?.drawOval(x+radius,y+radius,x-radius,y-radius,paint)
                canvas?.drawOval(x+radius,yp+radius,x-radius,yp-radius,paint)
            }}
        if (dx<0){
            for (i in RightCorner.x.toInt()..LeftCorner.x.toInt() ){
                println("in for")

                var x= i
                var y =LeftCorner.y
                var yp=RightCorner.y
                canvas?.drawOval(x+radius,y+radius,x-radius,y-radius,paint)
                canvas?.drawOval(x+radius,yp+radius,x-radius,yp-radius,paint)
            }}
        if(dy<0){
            for (i in RightCorner.y.toInt() .. LeftCorner.y.toInt()){

                var x=LeftCorner.x
                var y =i
                var xp=RightCorner.x
                canvas?.drawOval(x+radius,y+radius,x-radius,y-radius,paint)
                canvas?.drawOval(xp+radius,y+radius,xp-radius,y-radius,paint)
            }
        }
        if(dy>0){
            for (i in LeftCorner.y.toInt() ..RightCorner.y.toInt() ){

                var x=LeftCorner.x
                var y =i
                var xp=RightCorner.x
                canvas?.drawOval(x+radius,y+radius,x-radius,y-radius,paint)
                canvas?.drawOval(xp+radius,y+radius,xp-radius,y-radius,paint)


            }
        }

    }

}