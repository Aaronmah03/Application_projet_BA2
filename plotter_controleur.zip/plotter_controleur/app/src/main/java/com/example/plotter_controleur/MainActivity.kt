package com.example.plotter_controleur

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.graphics.Color.rgb
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible

import com.example.plotter_controleur.view_gestion.Square_maker
import com.example.plotter_controleur.view_gestion.Vecteur2
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.*
import kotlin.collections.ArrayList


class MainActivity : AppCompatActivity() {
    private var onBoard=false
    //bluetooth var
    var m_bluetoothAdapter :BluetoothAdapter?=null
    lateinit var m_pairedDevices:Set<BluetoothDevice>
    var REQUEST_ENABLE_BLUETOOTH=1
    lateinit var select_device_list: ListView
    companion object{
        val EXTRA_ADDRESS:String="Device_address"
    }
    // bluetooth
    private var deviceName: String? = null
    private var deviceAddress: String? = null
    var handler: Handler? = null
    var mmSocket: BluetoothSocket? = null
    var connectedThread: ConnectedThread? = null
    var createConnectThread: CreateConnectThread? = null
    var plotterOnTarget=false
    var codedMessage= arrayListOf<String>()
    //initialize var
    lateinit var drawView: DrawView
    lateinit var drawt: drawthread
    lateinit var validateB:Button
    lateinit var refresh:Button
    lateinit var blueB: Button
    lateinit var memoB: Button
    lateinit var drawB:Button
    lateinit var lineB: Button
    lateinit var circleB:Button
    lateinit var touchB: Button
    lateinit var squareB:Button
    var ArrayOfButton : ArrayList<Button> = arrayListOf<Button>()
    var ArrayOfBoolean : ArrayList<Boolean> = arrayListOf<Boolean>()
    //running bool
    var onT=false
    var onC=false
    var onR=false
    var onL=false
    var indice=0
    // screen dimensions
    var height: Int = 0
    var width: Int = 0
    private val CONNECTING_STATUS = 1 // used in bluetooth handler to identify message status

    private val MESSAGE_READ = 2

    @SuppressLint("ShowToast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawView = findViewById<DrawView>(R.id.board)
        validateB =findViewById<Button>(R.id.send)
        blueB = findViewById<Button>(R.id.bluetooth)
        memoB =findViewById(R.id.memory)
        refresh=findViewById(R.id.refresh)
        select_device_list=findViewById(R.id.select_device_list)
        drawB =findViewById<Button>(R.id.draw)
        lineB = findViewById<Button>(R.id.line)
        circleB =findViewById<Button>(R.id.circle)
        touchB = findViewById<Button>(R.id.touch)
        squareB =findViewById<Button>(R.id.rectangle)
        drawt=drawthread(drawView,this)
        ArrayOfButton.add(circleB)
        ArrayOfButton.add(touchB)
        ArrayOfButton.add(lineB)
        ArrayOfButton.add(squareB)
        ArrayOfBoolean.add(onT)
        ArrayOfBoolean.add(onC)
        ArrayOfBoolean.add(onL)
        ArrayOfBoolean.add(onR)

        // get screen dimensions
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        width = displayMetrics.widthPixels
        height = displayMetrics.heightPixels
        hideSystemUI()

        //bluetooth

        m_bluetoothAdapter= BluetoothAdapter.getDefaultAdapter()

        if(m_bluetoothAdapter==null){
            Toast.makeText(this,"this device doesn't support bluetooth",Toast.LENGTH_SHORT).show()
            return }
        if(!m_bluetoothAdapter!!.isEnabled){
            val enableBluetoothIndent =Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBluetoothIndent,REQUEST_ENABLE_BLUETOOTH)
        }
        deviceName = getIntent().getStringExtra("deviceName");
        if (deviceName != null){
            // Get the device address to make BT Connection
            deviceAddress = getIntent().getStringExtra("deviceAddress");
            // Show progree and connection status


            /*
            This is the most important piece of code. When "deviceName" is found
            the code will call a new thread to create a bluetooth connection to the
            selected device (see the thread code below)
             */

            }

    }


    //create a window that allow the user to select an saved shape =================================

    fun LoadMemoryPage(v: View){
        Square_maker(this)
        val ft = supportFragmentManager.beginTransaction()
        val prev = supportFragmentManager.findFragmentByTag("dialog")
        if (prev != null) {
            ft.remove(prev)
        }
        ft.addToBackStack(null)
        val Dialog = Square_maker(this)
        Dialog.isCancelable = false
        Dialog.show(ft, "dialog")
    }
    //leave and resume gestion =====================================================================

    fun allModeOff(){
        onT=false
        onL=false
        onR=false
        onC=false
    }
    override fun onBackPressed() {
        if (onBoard){
            unload()
            onBoard=false
        }
        else if(select_device_list.isClickable){nonBlue()}
        else{super.onBackPressed()
            if (createConnectThread != null) {
                createConnectThread!!.cancel()
            }
            val a = Intent(Intent.ACTION_MAIN)
            a.addCategory(Intent.CATEGORY_HOME)
            a.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(a)
        }

    }

    //page gestion =================================================================================
    fun LoadDraw(v: View){
        allModeOff()
        drawView.isVisible=true
        drawView.isClickable=true
        validateB.isVisible=true
        validateB.isClickable=true
        blueB.isVisible=false
        blueB.isClickable=false
        drawB.isVisible=false
        drawB.isClickable=false
        memoB.isClickable=false
        memoB.isVisible=false
        for( b in ArrayOfButton ){
            b.isClickable=true
            b.isVisible=true
            if (b==touchB){
                b.setBackgroundColor(rgb(50, 50, 250))
                onT=true
            }
            else{
                b.setBackgroundColor(rgb(100, 100, 255))
            }
        }
        onBoard=true

        drawt = drawthread(drawView, this)
        drawt.clear()

        drawt.init()

    }
    fun buttonToBool(b:Button){
        if (b==lineB){onL=true;println(""+onL+","+onT)}
        else if(b==circleB){onC=true;println("on circle mode")}
        else if (b==touchB){onT=true}
        else if (b==squareB){onR=true}
    }
    fun selected(v: View){
        allModeOff()

        for (b in ArrayOfButton){
            if (b==v){

                b.setBackgroundColor(rgb(50, 50, 250))
                buttonToBool(b)

            }
            else{
                b.setBackgroundColor(rgb(100, 100, 255))
            }
        }

    }
    fun unload(){ drawView.isVisible=false
        drawView.isClickable=false
        validateB.isVisible=false
        validateB.isClickable=false
        blueB.isVisible=true
        blueB.isClickable=true
        drawB.isVisible=true
        drawB.isClickable=true
        memoB.isClickable=true
        memoB.isVisible=true
        onBoard=false
        for (b in ArrayOfButton){
            b.isClickable=false
            b.isVisible=false}}
    fun unloadDraw(v: View){
        unload()
        send()
    }
    var ready=false
    fun send(){
        println("in fun")
        codedMessage.clear()
        if (!drawt.pts.isEmpty()){
            if(m_bluetoothAdapter!!.isEnabled){
        for(i in drawt.drawPoints){
            encode(i)

        }
                sendNextPoint()
        }}
    }
    fun encode(v:Vecteur2){
        //encode
        //add in coded message

    }
    fun waitForBool(){
        println("before")

        while (ready==false && ControlActivity.m_BluetoothSocket !=null ){
            getReturn()
        }
        println("outa while")
    }
    var returne=""
    fun getReturn(){
        if (ControlActivity.m_BluetoothSocket !=null)

        {
            println(" in if")
            try {
                println("in try")
                ControlActivity.m_BluetoothSocket!!.outputStream.write(returne.toByteArray())
            }catch (e: IOException){e.printStackTrace()}
        }
        if (returne=="true"){ready}
    }
    fun sendCommand(input:String) {
        println("in sendC")
        if (ControlActivity.m_BluetoothSocket !=null)
        {
            println(" in if")
            try {
                println("in try")
                ControlActivity.m_BluetoothSocket!!.outputStream.write(input.toByteArray())
            }catch (e: IOException){e.printStackTrace()}
        }


    }
    fun loadBluePage(v:View){bluetoothPage()}
    fun bluetoothPage(){
        select_device_list.isVisible=true
        select_device_list.isClickable=true
        refresh.isClickable=true
        refresh.isVisible=true
        blueB.isVisible=false
        blueB.isClickable=false
        drawB.isVisible=false
        drawB.isClickable=false
        memoB.isClickable=false
        memoB.isVisible=false
    }

    fun nonBlue(){select_device_list.isVisible=false
        select_device_list.isClickable=false
        refresh.isClickable=false
        refresh.isVisible=false
        blueB.isVisible=true
        blueB.isClickable=true
        drawB.isVisible=true
        drawB.isClickable=true
        memoB.isClickable=true
        memoB.isVisible=true}
    //  define Application design ===================================================================
    fun hideSystemUI() {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                // Set the content to appear under the system bars so that the
                // content doesn't resize when the system bars hide and show.
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                // Hide the nav bar and status bar
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN)
    }
    @RequiresApi(Build.VERSION_CODES.M)
    @SuppressLint("ShowToast")
    // get paired devices
    fun pairedDeviceList(v: View){
        m_pairedDevices=m_bluetoothAdapter!!.bondedDevices
        val list:ArrayList<BluetoothDevice> = ArrayList()
        println("post")
        if(!m_pairedDevices.isEmpty()){
            for (device:BluetoothDevice in m_pairedDevices){
                list.add(device)
                Log.i("device",""+device+""+device.name)
            }
        }
        else{Toast.makeText(this,"no paired device found",Toast.LENGTH_SHORT).show()}
        val adapter =ArrayAdapter(this,android.R.layout.simple_list_item_1,list)

        select_device_list.adapter=adapter

            select_device_list.onItemClickListener=AdapterView.OnItemClickListener { _, _, position, _ ->
                val device: BluetoothDevice = list[position]
                val address: String = device.address
                val bluetoothAdapter:BluetoothAdapter= BluetoothAdapter.getDefaultAdapter();
                createConnectThread =CreateConnectThread(bluetoothAdapter,address,device);
                createConnectThread!!.start()
                Toast.makeText(this,device.name,Toast.LENGTH_SHORT).show()
        }

    }

    //==============================================================================================
    @SuppressLint("ShowToast")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode==REQUEST_ENABLE_BLUETOOTH){
            if(resultCode==Activity.RESULT_OK){
                if (m_bluetoothAdapter!!.isEnabled){
                    Toast.makeText(this,"bluetooth has been enabled",Toast.LENGTH_SHORT).show()
                }
                else{Toast.makeText(this,"bluetooth has been disabled",Toast.LENGTH_SHORT).show()}
            }
            else if (resultCode==Activity.RESULT_CANCELED){
                Toast.makeText(this,"bluetooth has been canceled",Toast.LENGTH_SHORT).show()
            }
        }
    }
    inner class CreateConnectThread(var bluetoothAdapter:BluetoothAdapter , var address:String?,var device: BluetoothDevice)  :Thread() {
       val uuid: UUID = UUID.fromString("0dec3cc2-8be2-11ec-a8a3-0242ac120002")
        private val mmSocket: BluetoothSocket? by lazy(LazyThreadSafetyMode.NONE) {
            device.createRfcommSocketToServiceRecord(uuid)
        }

        var tryNbr=0
        override fun run() {
            // Cancel discovery because it otherwise slows down the connection.
            val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            var error=false
            bluetoothAdapter.cancelDiscovery()

            mmSocket?.let { socket ->
                // Connect to the remote device through the socket. This call blocks
                // until it succeeds or throws an exception.
                socket.connect()

                connectedThread = ConnectedThread(socket)
                connectedThread!!.run()
            }
        }
        fun cancel() {
            try {
                mmSocket?.close()
            } catch (e: IOException) {
                Log.e("Error", "Could not close the client socket", e)
            }
        }
        }




        inner class ConnectedThread(var mmsocket: BluetoothSocket?) : Thread() {

            private val mmInStream: InputStream = mmSocket!!.inputStream
            private val mmOutStream: OutputStream = mmSocket!!.outputStream
            private val mmBuffer: ByteArray = ByteArray(1024)

            var input:Int?=null
            override fun run() {
                var numBytes: Int // bytes returned from read()

                // Keep listening to the InputStream until an exception occurs.
                while (true) {
                    // Read from the InputStream.
                    numBytes = try {
                        mmInStream.read(mmBuffer)
                    } catch (e: IOException) {
                        Log.d("TAG", "Input stream was disconnected", e)
                        break
                    }

                }
            }

            // Call this from the main activity to send data to the remote device.
            fun write(bytes: ByteArray) {
                try {
                    mmOutStream.write(bytes)
                } catch (e: IOException) {
                    Log.e("TAG", "Error occurred when sending data", e)

                    return
                }
            }

            /* Call this from the main activity to shutdown the connection */
            fun cancel() {
                try {
                    mmSocket?.close();
                } catch (e: IOException) {
                }
            }

    }

    fun sendNextPoint(){
        if(codedMessage.size<indice+1){connectedThread!!.write(codedMessage[indice].toByteArray());indice+=1}
        else{indice=0}
    }
}




