package com.example.plotter_controleur



import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException
import java.util.*

class ControlActivity:AppCompatActivity() {
    companion object{
        var m_myUUID:UUID=UUID.fromString("0dec3cc2-8be2-11ec-a8a3-0242ac120002")
        var m_BluetoothSocket:BluetoothSocket?=null
        lateinit var m_progress:ProgressDialog
        lateinit var m_bluetoothAdapter:BluetoothAdapter
        var m_isConnected:Boolean=false
        var m_adress:String?=null

    }
    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.draw_view)
        println("machin")
        hideSystemUI()
        m_adress= intent.getStringExtra(MainActivity.EXTRA_ADDRESS)
        connectToDevice(this).execute()
    }
    fun getCommandeOn(v: View){
        sendCommand(1)
        Toast.makeText(this,"Commande Sended",Toast.LENGTH_LONG).show()
    }
    fun getCommandeOff(v:View){
        sendCommand(2)
        Toast.makeText(this,"Commande Sended",Toast.LENGTH_LONG).show()
    }

    fun sendCommand(input:Int) {
        println("in")
        if (m_BluetoothSocket!=null)
        {
            Toast.makeText(this,"bluetooth non nul",Toast.LENGTH_LONG).show()
            try {
                m_BluetoothSocket!!.outputStream.write(input)
            }catch (e:IOException){e.printStackTrace()}
        }

    }
    fun disconnect(v: View){
        if (m_BluetoothSocket!=null){
            try {
                m_BluetoothSocket!!.close()
                m_BluetoothSocket=null
                m_isConnected=false
            }catch (e:IOException){
                e.printStackTrace()
            }

        }
        finish()
    }
    private class connectToDevice(c: Context): AsyncTask<Void, Void, String>()
    {
        private var connectSuccess:Boolean=true
        @SuppressLint("StaticFieldLeak")
        private val context:Context
        init {
            this.context=c
        }
        override fun onPreExecute() {
            super.onPreExecute()
            m_progress= ProgressDialog.show(context,"Connecting ...","please wait")
        }

        override fun doInBackground(vararg params: Void?): String? {
            try {
                if (m_BluetoothSocket== null || !m_isConnected){
                    m_bluetoothAdapter= BluetoothAdapter.getDefaultAdapter()
                    val device:BluetoothDevice= m_bluetoothAdapter.getRemoteDevice(m_adress)
                    println(device.name)
                    m_BluetoothSocket=device.createInsecureRfcommSocketToServiceRecord(m_myUUID)
                    //stop searching device
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
                    m_BluetoothSocket!!.connect()
                }
            }catch (e:IOException){
                connectSuccess=false
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (!connectSuccess){
                Log.i("data","couldn't connect")
            }
            else if (connectSuccess){
                m_isConnected=true


            }
            m_progress.dismiss()
        }
    }
    @RequiresApi(Build.VERSION_CODES.KITKAT)
    fun hideSystemUI() {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                // Set the content to appear under the system bars so that the
                // content doesn't resize when the system bars hide and show.
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                // Hide the nav bar and status bar
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN)
    }
}