package com.example.plotter_controleur.view_gestion


import kotlin.math.sqrt
import kotlin.math.atan

//Helper class for vectorial calculations
class Vecteur2(var x: Float, var y: Float) {

    fun length(): Float {
        return sqrt(x*x + y * y)
    }

    fun lengthSquared(): Float { //Avoid heavy square root calculation when squared norm is needed
        return x*x + y*y
    }

    fun direction(): Vecteur2 {
        val length = length()
        return if (length != 0.0f)
            Vecteur2(x, y)/length
        else
            Vecteur2(0.0f, 0.0f)
    }

    fun dotProduct(other: Vecteur2): Float {
        return x * other.x + y * other.y
    }

    fun crossProduct(other: Vecteur2): Float {
        return x * other.y + y * other.x
    }

    fun clone(): Vecteur2 {
        return Vecteur2(x, y)
    }

    operator fun plus(other: Vecteur2): Vecteur2 {
        return Vecteur2(x + other.x, y + other.y)
    }

    operator fun minus(other: Vecteur2): Vecteur2 {
        return Vecteur2(x - other.x, y - other.y)
    }

    operator fun times(scalar: Float): Vecteur2 {
        return Vecteur2(x * scalar, y * scalar)
    }

    operator fun div(scalar: Float): Vecteur2 {
        return Vecteur2(x / scalar, y / scalar)
    }

    operator fun unaryMinus(): Vecteur2 {
        return Vecteur2(-x, -y)
    }
    fun arctan():Float{
        return atan((y/x).toDouble()).toFloat()
    }

}