package com.example.plotter_controleur.view_gestion


import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import androidx.appcompat.app.AppCompatActivity


import android.content.pm.ActivityInfo
import android.content.pm.ActivityInfo.FLAG_IMMERSIVE
import android.graphics.Color.*
import android.os.Build
import android.view.*

import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import android.widget.Button
import androidx.annotation.RequiresApi
import com.example.plotter_controleur.MainActivity
import com.example.plotter_controleur.R

class Square_maker (val mainActivity: MainActivity) : DialogFragment()  {

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreateDialog(bundle: Bundle?): Dialog {
        val builder = AlertDialog.Builder(getActivity())
        val activity= activity
        builder.setTitle("")
        builder.setView(R.layout.square_dialog)
        builder.setPositiveButton("Continue", DialogInterface.OnClickListener { _, _ ->mainActivity.connectedThread?.write("0".toByteArray()) })
        return builder.create() }


}




