package com.example.plotter_controleur

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import androidx.annotation.RequiresApi
import com.example.plotter_controleur.view_gestion.Vecteur2

class point (var position: Vecteur2, var radius:Float):drawingGestion(){
    val paint = Paint()

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun draw (canvas: Canvas?) {
        paint.color = Color.WHITE
        canvas?.drawOval(position.x - radius,position.y - radius,position.x + radius,position.y + radius, paint)

    }

}