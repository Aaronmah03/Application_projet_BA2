package com.example.plotter_controleur

import android.graphics.Canvas
import android.view.MotionEvent
import android.view.View

abstract class drawingGestion {
    abstract fun draw(canvas: Canvas?)

}
