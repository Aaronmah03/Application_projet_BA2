package com.example.plotter_controleur

import android.annotation.SuppressLint
import android.graphics.Canvas
import android.view.SurfaceView
import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.MotionEvent

class DrawView @JvmOverloads constructor (context: Context, attributes: AttributeSet? = null, defStyleAttr: Int = 0): SurfaceView(context, attributes,defStyleAttr){
    private lateinit var canvas: Canvas
    val drawables: ArrayList<drawingGestion> = ArrayList()
    val drawed=arrayListOf<drawingGestion>()
    fun draw() {
        if (holder.surface.isValid) {
            canvas = holder.lockCanvas()
            for (drawable in drawables) {
                drawable.draw(canvas)
            }
            holder.unlockCanvasAndPost(canvas)
        }
    }
    fun tempodraw(){
        if (holder.surface.isValid) {
            canvas = holder.lockCanvas()

            for (k in drawed){k.draw(canvas)}

            holder.unlockCanvasAndPost(canvas)
        }
    }
    fun addDrawable(drawable: drawingGestion) {
        drawables.add(drawable)
    }
    fun clearDrawables(){
        drawables.clear()
    }
    fun  clearDrawed(){
        drawed.clear()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        return true
    }

}